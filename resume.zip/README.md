[![](https://github.com/matveycodes/cv/releases/latest/download/preview.png)](https://github.com/matveycodes/cv/releases/latest/download/cv_kottsov_public.pdf)
